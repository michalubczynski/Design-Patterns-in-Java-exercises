package Stan;

public interface IStan {
    void uzupelnij();
    void wydawanieGumy();
    void wkladanieMonety();
    void przekrecanieGalki();
    void wydawanieMonety();
}
