package KolokwiumML;

public interface Observer {
    void update(LatajaceObservable orzel);
}
