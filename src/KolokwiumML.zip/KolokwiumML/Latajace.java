package KolokwiumML;

public interface Latajace extends LatajaceObservable {
    public void glos();
}
