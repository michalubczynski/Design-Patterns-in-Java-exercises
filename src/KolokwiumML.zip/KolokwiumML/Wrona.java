package KolokwiumML;

public class Wrona {
    public void glos(){
        System.out.println("WRONA-glos");
    }
}
