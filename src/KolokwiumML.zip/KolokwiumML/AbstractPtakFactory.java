package KolokwiumML;

public abstract class AbstractPtakFactory {
    public abstract Latajace createOrzelBielik();
    public abstract Latajace createOrzelKrzykliwy();
    public abstract Latajace createOrzelPolski();

}
