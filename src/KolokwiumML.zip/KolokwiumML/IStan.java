package KolokwiumML;

public interface IStan {
    void oznajmienieObserwacji();
    void czuwanie();
}
